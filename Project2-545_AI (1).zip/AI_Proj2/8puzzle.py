import heapq
import copy
from lib2to3.pgen2.pgen import generate_grammar
import time
from math import sqrt
from os import stat
from secrets import choice
# [Row, Column] in each index
# [[RIGHT],[LEFT],[DOWN],[UP]] for movement of empty tile
moves = [[0, 1], [0, -1], [1, 0], [-1, 0]]


class Node:

    def __init__(self, parent, state, empty_pos, dis, lvl) -> None:

        self.parent = parent
        self.state = state
        self.empty_pos = empty_pos
        self.dis = dis
        self.lvl = lvl

    def __lt__(self, other):
        return self.dis < other.dis


def printState(dest):
    if dest == None:
        return
    printState(dest.parent)
    for x in range(len(dest.state)):
        for y in range(len(dest.state[x])):
            print(dest.state[x][y], end=" ")
        print()
    print('\n')


# def simPrintState(node):  # For testing
#     for x in range(len(node.state)):
#         for y in range(len(node.state[x])):
#             print(node.state[x][y], end=" ")
#         print()
#     print('\n')

def getInvCount(arr):
    inv_count = 0
    empty_value = 0
    for i in range(0, 9):
        for j in range(i + 1, 9):
            if arr[j] != empty_value and arr[i] != empty_value and arr[i] > arr[j]:
                inv_count += 1
    return inv_count


def isSolvable(p):

    # Count inversions in given 8 puzzle
    inv = getInvCount([j for sub in p for j in sub])

    # return true if inversion count is even.
    return (inv % 2 == 0)


def eightGener():
    # Random 8 Puzzle Generator
    tiles = [0, 1, 2, 3, 4, 5, 6, 7, 8]
    gener_puzzle = [[0 for i in range(3)] for j in range(3)]
    for i in range(3):
        for j in range(3):
            x = choice(tiles)
            gener_puzzle[i][j] = x
            tiles.remove(x)
    return gener_puzzle


def findInd(state, tile_num):
    tile_pos = []
    for x in range(len(state)):
        for y in range(len(state[x])):
            if state[x][y] == tile_num:
                tile_pos = [x, y]
                return tile_pos


def calcHSCORE(state, goal):
    score = 0
    # Manhatten
    for x in range(len(state)):
        for y in range(len(state[x])):
            # Call findInd() to retrieve the position for each tile num in the puzzle
            curr_pos = findInd(state, state[x][y])
            goal_pos = findInd(goal, state[x][y])
            # Score the state base on the difference between the pos of x and then the pos y of the goal and current state
            score += ((abs(curr_pos[0] - goal_pos[0])) +
                      (abs(curr_pos[1] - goal_pos[1])))
    return score


def newState(state, old_empty_pos, new_empty_pos, parent, n_lvl, goal_state):
    row = 0
    col = 1
    # Perform a deep copy of the puzzle state to avoid usage of the original best_state node
    new_state = copy.deepcopy(state)
    # Switching spots between the empty tile and the non-empty tile after a move
    new_state[old_empty_pos[row]][old_empty_pos[col]
                                  ] = new_state[new_empty_pos[row]][new_empty_pos[col]]
    # Wipe the tile positioning at the new_empty _pos
    new_state[new_empty_pos[row]][new_empty_pos[col]] = 0
    h = calcHSCORE(new_state, goal_state)
    node = Node(parent, new_state, new_empty_pos, h, n_lvl)
    return node


def search(start_state, empty_pos, goal_state):
    # Heap Priority Queue to pop the next state
    pQ = []
    # List to keep track of all states previously generated
    PQ_Visited = []
    # Track the count of iterations to the final state
    iter = 0
    exists = False
    # Code to add in the root node to the heap tree
    h = calcHSCORE(start_state, goal_state)
    root = Node(None, start_state, empty_pos, h, 0)
    heapq.heappush(pQ, root)
    # A loop to perform the A* search till the Heap Priority Queue is 0 meaning that there are no more states to pop from the queue
    while len(pQ) != 0:
        exists = False
        best_state = heapq.heappop(pQ)
        heapq.heappush(PQ_Visited, best_state)
        # print("Selected state:\n")
        # simPrintState(best_state)
        # Print the state if its equal to the goal state
        if best_state.dis == 0:
            printState(best_state)
            print("Iterations:", iter)
            return
        else:
            row = 0
            col = 1
            for i in range(4):
                new_empty = [(best_state.empty_pos[row] + moves[i][0]),
                             (best_state.empty_pos[col] + moves[i][1])]
                # Code to generate the children for the root node
                if best_state.parent == None:
                    if ((new_empty[row] >= 0 and new_empty[row] < len(best_state.state)) and (new_empty[col] >= 0 and new_empty[col] < len(best_state.state[0]))):
                        nxt_lvl = best_state.lvl + 1
                        newChild = newState(
                            best_state.state, best_state.empty_pos, new_empty, best_state, nxt_lvl, goal_state)
                        heapq.heappush(pQ, newChild)
                        iter += 1
                # Code to generate Children of all nodes in the 2nd level of the tree and lower
                else:
                    if ((new_empty[row] >= 0 and new_empty[row] < len(best_state.state)) and (new_empty[col] >= 0 and new_empty[col] < len(best_state.state[0])) and ((new_empty[row] != best_state.parent.empty_pos[row]) and (new_empty[col] != best_state.parent.empty_pos[col]))):
                        nxt_lvl = best_state.lvl + 1
                        newChild = newState(
                            best_state.state, best_state.empty_pos, new_empty, best_state, nxt_lvl, goal_state)
                        for node in PQ_Visited:
                            if node.state == newChild.state:
                                exists = True
                                break
                        if not exists:
                            heapq.heappush(pQ, newChild)
                            iter += 1
                        else:
                            break


start_time = time.time()
# Solvable Final configuration
# Value 0 is used for empty space
goal = [[1, 2, 3],
        [4, 5, 6],
        [7, 8, 0]]

empty_tile_pos = [0,0]

# Function call to solve the puzzle
gener_puzzle = eightGener()
while isSolvable(gener_puzzle) == False:
    print("Not Solvable")
    print(gener_puzzle)
    time.sleep(2)
    gener_puzzle = eightGener()

print("Solvable\n")
print(gener_puzzle, "\n")
time.sleep(2)
for i in range(len(gener_puzzle)):
    for j in range(len(gener_puzzle[i])):
        if gener_puzzle[i][j] == 0:
                empty_tile_pos = [i, j]
search(gener_puzzle, empty_tile_pos, goal)


# initial = [[5, 4, 1],
#            [0, 2, 8],
#            [3, 6, 7]]

# # Blank tile coordinates in
# # initial configuration
# empty_tile_pos = [ 1, 0 ]

# if(isSolvable(initial)) :
#     print("Solvable")
#     print(initial)
#     search(initial, empty_tile_pos, goal)
# else :
#     print("Not Solvable")

# Print out the real execution time
print("--- %s seconds ---" % (time.time() - start_time))
